package com.example.parliamentapp.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.parliamentapp.*
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.model.Reaction

@Database(entities = [Member::class, Reaction::class], version = 9, exportSchema = false)
abstract class EduskuntaDatabase: RoomDatabase() {
    abstract val eduskuntaMemberDAO: EduskuntaMemberDAO
    abstract val eduskuntaMemberReactionDAO: MemberReactionDAO
    companion object {
        @Volatile
        private var INSTANCE: EduskuntaDatabase? = null
        fun getInstance(): EduskuntaDatabase {
            synchronized(this) {
                var instance =
                    INSTANCE
                if(instance == null) {
                    instance = Room.databaseBuilder(
                        MyApp.appContext,
                        EduskuntaDatabase::class.java,
                        "eduskunta_database"
                    ).fallbackToDestructiveMigration().build()
                    INSTANCE = instance
                }
                return instance
            }
        }
    }
}