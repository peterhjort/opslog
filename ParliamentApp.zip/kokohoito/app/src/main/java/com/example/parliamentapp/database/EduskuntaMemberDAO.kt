package com.example.parliamentapp.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.model.Reaction

@Dao
interface EduskuntaMemberDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(member: Member)
    @Update
    fun update(member: Member)
    @Query("select * from Member where hetekaId == :key")
    fun get(key: Int): LiveData<Member>
    @Query("select * from Member where party == :key")
    suspend fun getByParty(key: String): List<Member>?
    @Query("select * from Member")
    fun getAll(): LiveData<List<Member>>
}

@Dao
interface MemberReactionDAO {
    @Insert
    fun insert(reaction: Reaction)
    @Query("select * from Reaction where rid == :key")
    fun get(key: Long): Reaction?
    @Query("select * from Reaction where hetekaId == :key")
    fun getByHetekaId(key: Int): LiveData<List<Reaction>>
    @Query("select sum(value) from Reaction where hetekaId == :key")
    fun getSumByHetekaId(key: Int): LiveData<Int>
}
