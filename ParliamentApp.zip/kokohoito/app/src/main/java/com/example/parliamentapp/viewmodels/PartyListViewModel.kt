package com.example.parliamentapp.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.repositories.MembersRepository

class PartyListViewModel: ViewModel() {
    val parties: LiveData<List<String>> = Transformations.map(MembersRepository.members, { m -> extractParties(m) })

    private fun extractParties(memberList: List<Member>): List<String> {
        Log.d("ZZZ", "extrParties ${memberList.toString()}")
        return memberList.map { it.party }.toSortedSet().toList()
    }
}