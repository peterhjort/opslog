package com.example.parliamentapp.repositories

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.parliamentapp.database.EduskuntaDatabase
import com.example.parliamentapp.eduskuntaapi.EduskuntaMemberApi
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.model.Reaction

object MembersRepository {
    val members: LiveData<List<Member>> =
        EduskuntaDatabase.getInstance().eduskuntaMemberDAO.getAll()

    suspend fun refreshMembers() {
        try {
            val response = EduskuntaMemberApi.RETROFIT_SERVICE_MEMBER.getProperties()
            val mps = response as MutableList<Member>
            mps.forEach { EduskuntaDatabase.getInstance().eduskuntaMemberDAO.insert(it) }
            Log.d("ZZZ", "db updated")
        } catch (e: Exception) {
            Log.d("ZZZ", e.message ?: "Nothing")
        }
    }

    fun getByHetekaid(hetekaid: Int): Member? {
        Log.d("ZZZ", "getByHetekaid($hetekaid)")
        val member = members.value?.filter { it.hetekaId == hetekaid }?.get(0)
        Log.d("ZZZ", "${member}")
        return member
    }

    fun newReaction(hetekaId: Int, positive: Boolean) {
        Log.d("ZZZ", "newReaction($hetekaId, $positive)")
        EduskuntaDatabase.getInstance().eduskuntaMemberReactionDAO.insert(
            Reaction(
                hetekaId = hetekaId,
                value = if (positive) 1 else -1,
                time = System.currentTimeMillis()
            )
        )
    }
}