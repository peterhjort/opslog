package com.example.parliamentapp.viewmodels

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.repositories.ImagesRepository
import com.example.parliamentapp.repositories.MembersRepository
import com.example.parliamentapp.repositories.ReactionsRepository
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MemberDetailViewModel: ViewModel() {
    var member: Member? = null
    var image: Bitmap? = null
    lateinit var reactionSum: LiveData<Int>

    init {
        Log.d("ZZZ", "MemberDetailViewModel init")
    }

    override fun onCleared() {
        super.onCleared()
        Log.d("ZZZ", "MemberDetailViewModel onCleared()")
    }

    fun updateForHetekaId(hetekaId: Int) {
        member = MembersRepository.getByHetekaid(hetekaId)
        reactionSum = ReactionsRepository.getByHetekaId(hetekaId)
        image = member?.let { ImagesRepository.getImageBitmap(it.pictureUrl) }
    }

    fun newReaction(hetekaId: Int, positive: Boolean) {
        GlobalScope.launch(Dispatchers.IO, CoroutineStart.DEFAULT) {
            MembersRepository.newReaction(hetekaId, positive)
        }
    }
}
