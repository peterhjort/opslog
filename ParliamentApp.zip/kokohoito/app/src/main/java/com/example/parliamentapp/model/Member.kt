package com.example.parliamentapp.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Member(
    @PrimaryKey
    val hetekaId: Int,
    val seatNumber: Int = 0,
    val lastname: String,
    val firstname: String,
    val party: String,
    val minister: Boolean = false,
    val pictureUrl: String = ""
)

@Entity
data class Reaction(
    @PrimaryKey(autoGenerate = true)
    var rid: Int = 0,
    val hetekaId: Int,
    val value: Int,
    val time: Long,
    val note: String = ""
)

class Parliament(members: Collection<Member>) {
    val partyMap = members.groupBy { it.party }
}