package com.example.parliamentapp

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.parliamentapp.repositories.MembersRepository
import java.lang.Exception

class DataRefresher(context: Context, params: WorkerParameters): CoroutineWorker(context, params) {
    companion object {
        const val WORK_NAME = "com.example.parliamentapp.DataRefresher"
    }

    override suspend fun doWork(): Result {
        try {
            Log.d("ZZZ", "DataRefresher doWork()")
            MembersRepository.refreshMembers()
        } catch (e: Exception) {
            Log.d("ZZZ", e.message ?: "Nothing")
            return Result.retry()
        }
        return Result.success()
    }
}