package com.example.parliamentapp.repositories

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.parliamentapp.database.EduskuntaDatabase

object ReactionsRepository {
    fun getByHetekaId(hetekaId: Int): LiveData<Int> {
        return EduskuntaDatabase.getInstance().eduskuntaMemberReactionDAO.getSumByHetekaId(hetekaId)
    }
}
