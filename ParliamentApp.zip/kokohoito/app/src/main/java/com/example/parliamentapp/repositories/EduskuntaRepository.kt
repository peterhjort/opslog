package com.example.parliamentapp.repositories

import android.util.Log
import com.example.parliamentapp.database.EduskuntaDatabase
import com.example.parliamentapp.eduskuntaapi.EduskuntaMemberApi
import com.example.parliamentapp.model.Member

class EduskuntaRepository {
    suspend fun refreshMembers() {
        try {
            val response = EduskuntaMemberApi.RETROFIT_SERVICE_MEMBER.getProperties()
            val mps = response as MutableList<Member>
            mps.forEach { EduskuntaDatabase.getInstance().eduskuntaMemberDAO.insert(it) }
            Log.d("ZZZ", "db updated")
        } catch (e: Exception) {
            Log.d("ZZZ", e.message ?: "Nothing")
        }    }
}