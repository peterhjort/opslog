package com.example.parliamentapp.eduskuntaapi

import com.example.parliamentapp.model.Member
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET

//private const val BASE_URL = "https://avoindata.eduskunta.fi/api/v1/"
private const val BASE_URL = "https://users.metropolia.fi/~peterh/"

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(BASE_URL)
    .build()

interface EduskuntaMemberApiService {
    //@GET("seating/") // when accessing eduskunta directly
    @GET("seating.json")
    suspend fun getProperties(): List<Member>
}

object EduskuntaMemberApi {
    val RETROFIT_SERVICE_MEMBER : EduskuntaMemberApiService by lazy {
        retrofit.create(EduskuntaMemberApiService::class.java) }
}