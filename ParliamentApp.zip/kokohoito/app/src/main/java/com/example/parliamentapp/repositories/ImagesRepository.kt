package com.example.parliamentapp.repositories

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.parliamentapp.MyApp
import java.io.InputStream
import java.lang.Exception
import java.net.URL

object ImagesRepository {
    fun getImageBitmap(url: String): Bitmap {
        val context = MyApp.appContext
        val filename = url.substringAfterLast("/")
        return try {
            val instream = context.openFileInput(filename)
            val bitmap = BitmapFactory.decodeStream(instream)
            instream.close()
            Log.d("ZZZ", "found in cache: $url")
            bitmap
        } catch (e: Exception) {
            Log.d("ZZZ", "not in cache: $filename")
            val imageUrl = "https://avoindata.eduskunta.fi/$url"
            val bitmap = BitmapFactory.decodeStream(URL(imageUrl).content as InputStream)
            MyApp.appContext.openFileOutput(filename, Context.MODE_PRIVATE).use {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, it)
                it.close()
            }
            bitmap
        }
    }
}