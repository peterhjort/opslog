package com.example.parliamentapp.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.parliamentapp.R
import com.example.parliamentapp.databinding.FragmentMemberListBinding
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.viewmodels.MemberListViewModel

class FragmentMemberList : Fragment() {

    val args: FragmentMemberListArgs by navArgs()

    companion object {
        fun newInstance() = FragmentMemberList()
    }

    private lateinit var viewModel: MemberListViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val party = args.party

        viewModel = ViewModelProvider(this).get(MemberListViewModel::class.java)
        val binding = FragmentMemberListBinding.inflate(
            inflater,
            container, false
        )

        viewModel.setMemberList(party)

        viewModel.members.observe(viewLifecycleOwner, Observer {
            (binding.memberList.adapter as MemberListAdapter).notifyDataSetChanged()
        })

        binding.memberList.layoutManager = LinearLayoutManager(activity)
        binding.memberList.adapter =
            activity?.let {
                MemberListAdapter(
                    it,
                    viewModel.members
                )
            }

        return binding.root
    }
}

class MemberListAdapter(val activity: Context, val list: LiveData<List<Member>>) :
    RecyclerView.Adapter<MemberViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemberViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.member_list_item, parent, false) as LinearLayout
        return MemberViewHolder(view)
    }

    override fun onBindViewHolder(holder: MemberViewHolder, position: Int) {
        val item = list.value?.get(position)
        if (item != null) {
            (holder.itemView).apply {
                findViewById<TextView>(R.id.name).text = "${item.firstname} ${item.lastname}"
                findViewById<TextView>(R.id.partyetc).text =
                    item.party + if (item.minister) " ministeri" else ""
                setOnClickListener {
                    val action =
                        FragmentMemberListDirections.actionFragmentMemberListToFragmentMemberDetails(
                            item.hetekaId
                        )
                    it.findNavController().navigate(action)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return list.value?.size ?: 0
    }
}

class MemberViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

