package com.example.parliamentapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.navArgs
import com.example.parliamentapp.databinding.FragmentMemberDetailsBinding
import com.example.parliamentapp.viewmodels.MemberDetailViewModel
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class FragmentMemberDetails : Fragment() {

    val args: FragmentMemberDetailsArgs by navArgs()

    companion object {
        fun newInstance() = FragmentMemberDetails()
    }

    private lateinit var viewModel: MemberDetailViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val hetekaid = args.hetekaid

        viewModel = ViewModelProvider(this).get(MemberDetailViewModel::class.java)
        val binding = FragmentMemberDetailsBinding.inflate(
            inflater,
            container, false
        )

        if (hetekaid == null) {
            //onBackPressed()
        } else {
            GlobalScope.launch(Dispatchers.IO, CoroutineStart.DEFAULT) {
                viewModel.updateForHetekaId(hetekaid)
                if (viewModel.member != null) {
                    viewModel.viewModelScope.launch {
                        binding.myMP = viewModel.member
                        //binding.reacts = viewModel.reactionSum
                        binding.imageView.setImageBitmap(viewModel.image)
                        viewModel.reactionSum.observe(viewLifecycleOwner, Observer {
                            binding.reacts = viewModel.reactionSum.value
                        })
                    }
                }
            }
            binding.plusbutton.setOnClickListener {
                viewModel.newReaction(hetekaid, true)
                binding.plusbutton.isEnabled = false
            }
            binding.minusbutton.setOnClickListener {
                viewModel.newReaction(hetekaid, false)
                binding.minusbutton.isEnabled = false
            }
        }


        //viewModel.setMemberList()
/*
        viewModel.reactionSum.observe(viewLifecycleOwner, Observer {
            (binding.memberList.adapter as MemberListAdapter).notifyDataSetChanged()
        })

        binding.memberList.layoutManager = LinearLayoutManager(activity)
*/
        return binding.root
    }
}