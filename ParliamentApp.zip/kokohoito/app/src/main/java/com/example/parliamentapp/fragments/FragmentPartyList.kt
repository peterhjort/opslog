package com.example.parliamentapp.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.parliamentapp.R
import com.example.parliamentapp.databinding.FragmentPartyListBinding
import com.example.parliamentapp.viewmodels.PartyListViewModel

class FragmentPartyList : Fragment() {

    companion object {
        fun newInstance() = FragmentPartyList()
    }

    private lateinit var viewModel: PartyListViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        viewModel = ViewModelProvider(this).get(PartyListViewModel::class.java)
        val binding = FragmentPartyListBinding.inflate(
            inflater,
            container, false
        )
        viewModel.parties.observe(viewLifecycleOwner, Observer {
            (binding.partylist.adapter as PartyListAdapter).notifyDataSetChanged()
        })
        binding.partylist.layoutManager = LinearLayoutManager(activity)
        binding.partylist.adapter =
            activity?.let {
                PartyListAdapter(
                    it,
                    viewModel.parties
                )
            }

        return binding.root
    }
}

class PartyListAdapter(val activity: Context, val list: LiveData<List<String>>) :
    RecyclerView.Adapter<PartyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PartyViewHolder {
        return PartyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.party_list_item,
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: PartyViewHolder, position: Int) {
        (holder.itemView as TextView).apply {
            text = list.value?.get(position) ?: "unknown"
            setOnClickListener {
                val action =
                    FragmentPartyListDirections.actionPartylistToFragmentMemberList(text.toString())
                it.findNavController().navigate(action)
            }
        }
    }

    override fun getItemCount(): Int {
        return list.value?.size ?: 0
    }
}

class PartyViewHolder(view: View) : RecyclerView.ViewHolder(view)

