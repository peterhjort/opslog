package com.example.parliamentapp.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.example.parliamentapp.model.Member
import com.example.parliamentapp.repositories.MembersRepository

class MemberListViewModel : ViewModel() {
    lateinit var members: LiveData<List<Member>>

    fun setMemberList(party: String? = null) {
        members = Transformations.map(MembersRepository.members, { m -> m.filter { if(party == null) true else party == it.party} })
    }

    init {
        Log.d("ZZZ", "MemberListViewModel init")
    }

    override fun onCleared() {
        super.onCleared()
        Log.i("ZZZ", "MemberListViewModel onCleared()")
    }
}